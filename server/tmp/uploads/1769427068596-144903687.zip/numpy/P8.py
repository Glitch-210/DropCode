# Practical 8: Exam Result – 2D Array
# Question

import numpy as np
# Create a 2D NumPy array representing marks of 3 students in 3 subjects.
marks = np.array([[78, 85, 90],
                  [65, 70, 72],
                  [88, 92, 80]]
)

# 1. Calculate total marks of each student
print(np.sum(marks , axis = 1))

# 2. Calculate subject-wise average
print(np.sum(marks , axis = 0))

# print(np.mean(marks , axis = 1))
# print(np.median(marks , axis = 0))

